"""Training loop: official loss/optimizer/schedule, logging, resumable checkpoints.

Run directory layout:
    config.json       resolved config incl. provenance
    metrics.jsonl     one JSON row per evaluation
    checkpoints/latest.pt   (atomic overwrite) + checkpoints/step_XXXXXXX.pt milestones
    DONE              written when max_steps is reached
The test split is never evaluated here; see scripts/final_eval.py.
"""
from __future__ import annotations

import json
import os
import random
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from .data import (ANSWER_POS_IN_Y, LOSS_POSITIONS, EpochBatcher, inputs_targets,
                   make_splits, official_batch_size)
from .model import build_model, count_params


# ---------------------------------------------------------------- loss / metrics
def seq_loss_and_correct(logits: torch.Tensor, y: torch.Tensor, positions: list[int]):
    """Mean cross-entropy over the selected target positions, and per-example correctness.

    logits (B, T, V), y (B, T). An example is correct iff argmax is right at *every* selected
    position (C training.py:251-267). Argmax is over the full vocabulary.
    """
    lg, tg = logits[:, positions, :], y[:, positions]                 # (B, P, V), (B, P)
    loss = F.cross_entropy(lg.reshape(-1, lg.shape[-1]), tg.reshape(-1))
    correct = (lg.argmax(-1) == tg).all(dim=1)                          # (B,)
    return loss, correct


@torch.no_grad()
def evaluate(model, seq: torch.Tensor, positions: list[int]) -> dict:
    was_training = model.training
    model.eval()
    x, y = inputs_targets(seq)
    logits = model(x)
    loss, correct = seq_loss_and_correct(logits, y, positions)
    a_loss, a_correct = seq_loss_and_correct(logits, y, [ANSWER_POS_IN_Y])
    model.train(was_training)
    return {"loss": loss.item(), "acc": correct.float().mean().item(),
            "answer_loss": a_loss.item(), "answer_acc": a_correct.float().mean().item()}


def lr_lambda_factory(warmup_steps: int):
    # C training.py:199-203 with LambdaLR: update k (0-indexed) uses lr * min(k/warmup, 1).
    return lambda k: min(float(k) / max(warmup_steps, 1), 1.0)


def eval_steps(max_steps: int, every: int, n_log: int) -> set[int]:
    log_pts = np.unique(np.round(np.logspace(0, np.log10(max(max_steps, 1)), n_log)).astype(int))
    return {0, max_steps} | set(range(every, max_steps + 1, every)) | set(log_pts.tolist())


# ---------------------------------------------------------------- RNG helpers
def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def rng_state() -> dict:
    s = {"python": random.getstate(), "numpy": np.random.get_state(),
         "torch": torch.get_rng_state()}
    if torch.cuda.is_available():
        s["cuda"] = torch.cuda.get_rng_state_all()
    return s


def set_rng_state(s: dict) -> None:
    random.setstate(s["python"])
    np.random.set_state(s["numpy"])
    torch.set_rng_state(s["torch"])
    if "cuda" in s and torch.cuda.is_available():
        torch.cuda.set_rng_state_all(s["cuda"])


def _atomic_save(obj, path: Path) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    torch.save(obj, tmp)
    os.replace(tmp, path)  # atomic on the same filesystem; a crash never leaves a half file


# ---------------------------------------------------------------- main loop
def train(cfg: dict, out_dir: str | Path, device: str | None = None,
          resume: bool = True, quiet: bool = False, stop_at: int | None = None) -> Path:
    """Train to cfg.train.max_steps. `stop_at` halts early (used to test resumption)."""
    out = Path(out_dir)
    (out / "checkpoints").mkdir(parents=True, exist_ok=True)
    device = device or ("cuda" if torch.cuda.is_available() else "cpu")
    torch.set_float32_matmul_precision("highest")      # fp32, no TF32 (C: fp32)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    tc, oc, prot = cfg["train"], cfg["optim"], cfg["protocol"]
    seed, max_steps = tc["seed"], tc["max_steps"]
    positions = LOSS_POSITIONS[tc["loss_positions"]]

    splits = make_splits(cfg)            # deterministic; independent of the run seed
    train_seq = splits.train.to(device)
    val_seq = splits.val.to(device)      # test split intentionally NOT moved or used
    n_train = len(train_seq)
    bs = official_batch_size(n_train) if tc["batch_size"] == "auto" else int(tc["batch_size"])

    seed_everything(seed)
    model = build_model(cfg, len(splits.vocab)).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=oc["lr"], betas=tuple(oc["betas"]),
                            eps=oc["eps"], weight_decay=oc["weight_decay"])
    if oc["anneal"]:
        raise NotImplementedError("Annealing is not used in the paper's experiments.")
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lr_lambda_factory(oc["warmup_steps"]))
    batcher = EpochBatcher(n_train, bs, seed)

    step, elapsed = 0, 0.0
    ckpt_path = out / "checkpoints" / "latest.pt"
    metrics_path = out / "metrics.jsonl"
    if resume and ckpt_path.exists():
        # Load to CPU: RNG states must be CPU ByteTensors; model/optimizer load_state_dict
        # moves tensors to the parameters' device.
        ck = torch.load(ckpt_path, map_location="cpu", weights_only=False)
        if ck["config"] != cfg:
            raise ValueError("Checkpoint config differs from requested config; use a new out_dir.")
        model.load_state_dict(ck["model"])
        opt.load_state_dict(ck["optimizer"])
        sched.load_state_dict(ck["scheduler"])
        batcher.load_state_dict(ck["batcher"])
        set_rng_state(ck["rng"])
        step, elapsed = ck["step"], ck["elapsed_sec"]
        # Drop metric rows written after this checkpoint (e.g. before a disconnect).
        if metrics_path.exists():
            rows = [json.loads(l) for l in metrics_path.read_text().splitlines() if l.strip()]
            keep = [r for r in rows if r["step"] <= step]
            metrics_path.write_text("".join(json.dumps(r) + "\n" for r in keep))
        if not quiet:
            print(f"Resumed from step {step}")
    else:
        metrics_path.write_text("")
        with open(out / "config.json", "w") as fh:
            json.dump({**cfg, "_derived": {"batch_size": bs, "n_train": n_train,
                       "n_val": len(splits.val), "n_test": len(splits.test),
                       "params": count_params(model), "device": device,
                       "torch": torch.__version__}}, fh, indent=2)

    schedule = eval_steps(max_steps, prot["eval_every"], prot["eval_log_points"])

    def save(tag_milestone: bool):
        state = {"model": model.state_dict(), "optimizer": opt.state_dict(),
                 "scheduler": sched.state_dict(), "batcher": batcher.state_dict(),
                 "rng": rng_state(), "step": step, "elapsed_sec": elapsed, "config": cfg}
        _atomic_save(state, ckpt_path)
        if tag_milestone:
            _atomic_save({"model": model.state_dict(), "step": step, "config": cfg},
                         out / "checkpoints" / f"step_{step:07d}.pt")

    def log(train_batch_loss):
        tr = evaluate(model, train_seq, positions)
        va = evaluate(model, val_seq, positions)
        row = {"step": step, "epoch": batcher.epoch, "lr": opt.param_groups[0]["lr"],
               "elapsed_sec": round(elapsed, 3), "train_batch_loss": train_batch_loss,
               **{f"train_{k}": v for k, v in tr.items()},
               **{f"val_{k}": v for k, v in va.items()},
               "param_norm": torch.sqrt(sum((p.detach() ** 2).sum() for p in model.parameters())).item()}
        with open(metrics_path, "a") as fh:
            fh.write(json.dumps(row) + "\n")
        if not quiet and (step % 1000 == 0 or step == max_steps):
            print(f"step {step:>7} | train loss {tr['loss']:.4f} acc {tr['acc']:.3f} | "
                  f"val loss {va['loss']:.4f} acc {va['acc']:.3f} | {elapsed:7.1f}s", flush=True)

    model.train()
    if step == 0:
        log(None)
    t0 = time.perf_counter()
    while step < max_steps and (stop_at is None or step < stop_at):
        idx = batcher.next_indices().to(device)
        x, y = inputs_targets(train_seq[idx])
        loss, _ = seq_loss_and_correct(model(x), y, positions)
        opt.zero_grad(set_to_none=True)
        loss.backward()
        opt.step()
        sched.step()
        step += 1
        now = time.perf_counter()
        elapsed += now - t0
        t0 = now
        if step in schedule:
            log(loss.item())
            t0 = time.perf_counter()        # exclude eval time from training time
        if step % prot["checkpoint_every"] == 0 or step == max_steps:
            save(tag_milestone=True)
            t0 = time.perf_counter()
    if stop_at is not None and step == stop_at and step % prot["checkpoint_every"]:
        save(tag_milestone=False)
    if step >= max_steps:
        (out / "DONE").write_text(str(step))
    return out
