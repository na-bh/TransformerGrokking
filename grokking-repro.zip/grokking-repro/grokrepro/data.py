"""Modular-addition data, matching openai/grok (commit 3d64b1d) token format and split.

Each example is a 7-token sequence
        <eos>  a  +  b  =  c  <eos>          positions 0..6
Model input  x = seq[:, :-1]  -> (N, 6):  <eos> a + b = c
Model target y = seq[:, 1:]   -> (N, 6):  a + b = c <eos>
x[:, t] is used to predict y[:, t] = seq[:, t+1]. The answer c is predicted at t = 4, where
the input token is '='; c itself enters the input only at t = 5.
"""
from __future__ import annotations

import itertools
import math
from dataclasses import dataclass

import numpy as np
import torch

EOS = "<|eos|>"
EQ = "="

# Operator tokens of the official shared vocabulary (C data.py VALID_OPERATORS keys).
_OFFICIAL_OPERATORS = [
    "+", "-", "*", "/", "**2+", "**3+", "x**2+y**2_mod_97", "x**2+y**2+x*y_mod_97",
    "x**2+y**2+x*y+x_mod_97", "x**3+x*y_mod_97", "x**3+x*y**2+y_mod_97",
    "(x._value//y)if(y._value%2==1)else(x-y)_mod_97", "s5", "s5conj", "s5aba", "+*", "+-",
    "sort", "reverse", "copy",
]

# Index of target positions (in y) that the losses use.
EQ_POS_IN_Y = 3                    # y = [a, +, b, =, c, <eos>]
LOSS_POSITIONS = {
    "rhs_after_eq": [4, 5],        # official: c and trailing <eos>
    "answer_only": [4],            # exploratory: c only
}
ANSWER_POS_IN_Y = 4


def build_vocab(kind: str, modulus: int) -> list[str]:
    if kind == "official":
        if modulus != 97:
            raise ValueError("The official vocabulary hard-codes the numbers 0..96.")
        perms = ["".join(map(str, p)) for p in itertools.permutations(range(5))]
        return [EOS, EQ] + sorted(_OFFICIAL_OPERATORS) + [str(i) for i in range(97)] + perms
    if kind == "minimal":
        return [EOS, EQ, "+"] + [str(i) for i in range(modulus)]
    raise ValueError(kind)


@dataclass
class Splits:
    vocab: list[str]
    stoi: dict[str, int]
    train: torch.Tensor   # (N_train, 7) int64 token ids
    val: torch.Tensor     # (N_val, 7)
    test: torch.Tensor    # (N_test, 7)
    train_pairs: np.ndarray  # (N_train, 2) operands (a, b), kept for checking
    val_pairs: np.ndarray
    test_pairs: np.ndarray


def all_equations(modulus: int) -> np.ndarray:
    """(p*p, 3) array of (a, b, c) in itertools.product order, like C data.py:213."""
    rows = [(a, b, (a + b) % modulus) for a, b in itertools.product(range(modulus), repeat=2)]
    return np.array(rows, dtype=np.int64)


def official_order(n: int, seed: int) -> list[int]:
    """The permutation produced by C data.py:345-347 (RandomState(seed).shuffle on a list).

    numpy's shuffle draws depend only on the sequence length, so shuffling a list of indices
    yields exactly the reordering applied to the official list of equation strings.
    """
    order = list(range(n))
    np.random.RandomState(seed=seed).shuffle(order)
    return order


def encode(eqs: np.ndarray, stoi: dict[str, int]) -> torch.Tensor:
    e, eq, plus = stoi[EOS], stoi[EQ], stoi["+"]
    num = np.array([stoi[str(i)] for i in range(int(eqs.max()) + 1)])
    seq = np.stack(
        [np.full(len(eqs), e), num[eqs[:, 0]], np.full(len(eqs), plus),
         num[eqs[:, 1]], np.full(len(eqs), eq), num[eqs[:, 2]], np.full(len(eqs), e)],
        axis=1,
    )
    return torch.from_numpy(seq).long()


def make_splits(cfg: dict) -> Splits:
    d, prot = cfg["data"], cfg["protocol"]
    p = d["modulus"]
    if d["operator"] != "+":
        raise NotImplementedError("Only modular addition is implemented.")
    vocab = build_vocab(d["vocab"], p)
    stoi = {s: i for i, s in enumerate(vocab)}

    eqs = all_equations(p)
    order = np.array(official_order(len(eqs), d["split_shuffle_seed"]))
    n_train = round(len(eqs) * d["train_pct"] / 100.0)   # C data.py:169 (Python round)
    train_idx, heldout_idx = order[:n_train], order[n_train:]

    # DEPARTURE: partition the official validation set into validation and test.
    rng = np.random.RandomState(prot["heldout_split_seed"])
    heldout_idx = heldout_idx[rng.permutation(len(heldout_idx))]
    n_test = round(len(heldout_idx) * prot["heldout_test_fraction"])
    test_idx, val_idx = heldout_idx[:n_test], heldout_idx[n_test:]

    return Splits(
        vocab=vocab, stoi=stoi,
        train=encode(eqs[train_idx], stoi), val=encode(eqs[val_idx], stoi),
        test=encode(eqs[test_idx], stoi),
        train_pairs=eqs[train_idx, :2], val_pairs=eqs[val_idx, :2],
        test_pairs=eqs[test_idx, :2],
    )


def official_batch_size(n_train: int) -> int:
    """C data.py:435: min(512, ceil(n/2))."""
    return min(512, math.ceil(n_train / 2.0))


def inputs_targets(seq: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    """C data.py:466-467."""
    return seq[:, :-1], seq[:, 1:]


class EpochBatcher:
    """Epoch-based minibatches without replacement; last smaller batch is kept (C data.py:441-468).

    Uses its own torch.Generator so its state can be checkpointed and restored exactly.
    """

    def __init__(self, n: int, batch_size: int, seed: int):
        self.n, self.batch_size = n, batch_size
        self.gen = torch.Generator().manual_seed(seed)
        self.epoch = 0
        self._new_epoch()

    def _new_epoch(self):
        self.perm = torch.randperm(self.n, generator=self.gen)
        self.pos = 0

    def next_indices(self) -> torch.Tensor:
        if self.pos >= self.n:
            self.epoch += 1
            self._new_epoch()
        idx = self.perm[self.pos:self.pos + self.batch_size]
        self.pos += self.batch_size
        return idx

    def state_dict(self) -> dict:
        return {"gen": self.gen.get_state(), "perm": self.perm.clone(),
                "pos": self.pos, "epoch": self.epoch}

    def load_state_dict(self, s: dict) -> None:
        self.gen.set_state(s["gen"])
        self.perm, self.pos, self.epoch = s["perm"].clone(), s["pos"], s["epoch"]
