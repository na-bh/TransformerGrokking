"""Decoder-only Transformer matching openai/grok transformer.py (commit 3d64b1d).

Notation: B = batch, T = sequence length (6 here), D = d_model (128), H = heads (4),
d_h = D/H (32), F = d_ff (512), V = vocabulary size (239).

Shapes through one forward pass:
    tokens          (B, T)            int64
    token emb       (B, T, D)         nn.Embedding, N(0,1) init, not scaled
    + positional    (T, D)            fixed sinusoid, broadcast over B
    per block:
      Q, K, V       (B, H, T, d_h)    from (B, T, D) via D x D matrices, split into heads
      scores        (B, H, T, T)      Q K^T / sqrt(d_h); entry [.., i, j] = query i vs key j
      masked scores (B, H, T, T)      -inf where j > i (future keys)
      weights       (B, H, T, T)      softmax over the last axis; rows sum to 1, zero above diag
      head outputs  (B, H, T, d_h)    weights @ V
      concat        (B, T, D)         heads side by side, then output projection W_o
      FFN           (B, T, D) -> (B, T, F) -> (B, T, D)
    logits          (B, T, V)         untied unembedding, no bias
"""
from __future__ import annotations

import math

import torch
import torch.nn as nn
import torch.nn.functional as F


def sinusoidal_positions(context_len: int, d_model: int) -> torch.Tensor:
    """Even dims: sin(pos / 10000^(i/D)); odd dims: cos(pos / 10000^((i-1)/D)). C transformer.py:325-334."""
    pe = torch.zeros(context_len, d_model, dtype=torch.float64)
    pos = torch.arange(context_len, dtype=torch.float64)[:, None]
    i = torch.arange(0, d_model, 2, dtype=torch.float64)
    div = 10000 ** (i / d_model)
    pe[:, 0::2] = torch.sin(pos / div)
    pe[:, 1::2] = torch.cos(pos / div)
    return pe.float()


class CausalSelfAttention(nn.Module):
    def __init__(self, d_model: int, n_heads: int, max_context_len: int):
        super().__init__()
        assert d_model % n_heads == 0
        self.n_heads, self.d_head = n_heads, d_model // n_heads
        # One D x D matrix per role == H stacked D x d_h per-head matrices (official layout).
        self.W_q = nn.Linear(d_model, d_model, bias=False)
        self.W_k = nn.Linear(d_model, d_model, bias=False)
        self.W_v = nn.Linear(d_model, d_model, bias=False)
        self.W_o = nn.Linear(d_model, d_model, bias=False)
        mask = torch.tril(torch.ones(max_context_len, max_context_len, dtype=torch.bool))
        self.register_buffer("causal_mask", mask, persistent=False)

    def _split_heads(self, t: torch.Tensor) -> torch.Tensor:
        B, T, D = t.shape
        return t.view(B, T, self.n_heads, self.d_head).transpose(1, 2)  # (B, H, T, d_h)

    def forward(self, x: torch.Tensor, return_weights: bool = False):
        B, T, D = x.shape
        q = self._split_heads(self.W_q(x))
        k = self._split_heads(self.W_k(x))
        v = self._split_heads(self.W_v(x))

        scores = q @ k.transpose(-2, -1) / math.sqrt(self.d_head)       # (B, H, T, T)
        allowed = self.causal_mask[:T, :T]                               # (T, T), True on/below diag
        scores = scores.masked_fill(~allowed, float("-inf"))
        weights = torch.softmax(scores, dim=-1)                          # (B, H, T, T)

        heads = weights @ v                                              # (B, H, T, d_h)
        out = heads.transpose(1, 2).reshape(B, T, D)                     # (B, T, D)
        out = self.W_o(out)
        return (out, weights) if return_weights else (out, None)


class DecoderBlock(nn.Module):
    """Post-LN block (C transformer.py:228-234):
         x = LN1(x + Attn(x));  x = LN2(x + Dropout(FFN(x)))"""

    def __init__(self, d_model, n_heads, d_ff, dropout, activation, max_context_len):
        super().__init__()
        self.attn = CausalSelfAttention(d_model, n_heads, max_context_len)
        self.ln1 = nn.LayerNorm(d_model)
        act = {"relu": nn.ReLU, "gelu": nn.GELU}[activation]
        self.ffn = nn.Sequential(
            nn.Linear(d_model, d_ff, bias=False), act(), nn.Linear(d_ff, d_model, bias=False)
        )
        self.drop = nn.Dropout(dropout)
        self.ln2 = nn.LayerNorm(d_model)

    def forward(self, x, return_weights=False):
        a, w = self.attn(x, return_weights)
        x = self.ln1(x + a)
        x = self.ln2(x + self.drop(self.ffn(x)))
        return x, w


class Transformer(nn.Module):
    def __init__(self, vocab_size: int, n_layers: int, n_heads: int, d_model: int, d_ff: int,
                 dropout: float, activation: str, norm: str, positional: str,
                 max_context_len: int):
        super().__init__()
        if norm != "post" or positional != "sinusoidal":
            raise NotImplementedError("Only the official post-LN / sinusoidal variant is implemented.")
        self.embed = nn.Embedding(vocab_size, d_model)
        self.register_buffer("pos", sinusoidal_positions(max_context_len, d_model), persistent=False)
        self.blocks = nn.ModuleList(
            DecoderBlock(d_model, n_heads, d_ff, dropout, activation, max_context_len)
            for _ in range(n_layers)
        )
        self.unembed = nn.Linear(d_model, vocab_size, bias=False)

    def forward(self, tokens: torch.Tensor, return_weights: bool = False):
        T = tokens.shape[1]
        h = self.embed(tokens) + self.pos[:T]          # (B, T, D)
        all_w = []
        for block in self.blocks:
            h, w = block(h, return_weights)
            all_w.append(w)
        logits = self.unembed(h)                       # (B, T, V)
        return (logits, all_w) if return_weights else logits


def build_model(cfg: dict, vocab_size: int) -> Transformer:
    m = cfg["model"]
    return Transformer(vocab_size, m["n_layers"], m["n_heads"], m["d_model"], m["d_ff"],
                       m["dropout"], m["activation"], m["norm"], m["positional"],
                       m["max_context_len"])


def count_params(model: Transformer) -> dict:
    total = sum(p.numel() for p in model.parameters())
    emb = model.embed.weight.numel() + model.unembed.weight.numel()
    return {"total": total, "embedding_and_unembedding": emb, "non_embedding": total - emb}
