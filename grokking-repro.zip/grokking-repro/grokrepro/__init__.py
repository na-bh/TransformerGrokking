"""Grokking reproduction (Power et al. 2022), modular addition."""
