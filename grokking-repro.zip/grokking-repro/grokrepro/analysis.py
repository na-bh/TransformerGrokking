"""Analysis of run directories: curves, timing metrics, and a declared delay criterion.

Timing metrics (thresholds from the paper: P section 3.1.1 and Fig. 1 caption use 99%):
    t_train99      first evaluated step with train accuracy >= 0.99
    t_val99        first evaluated step with validation accuracy >= 0.99
    val_at_train99 validation accuracy at t_train99
    best_val_acc   max validation accuracy over the run (the Fig. 2 right metric)
Times are upper bounds with resolution set by the eval schedule (every 100 steps after warmup).

Delayed-generalization label (OUR operational definition, fixed before seeing results;
the paper gives no numeric criterion):
    "delayed"        t_val99 exists, t_val99 >= 10 * t_train99, and val_at_train99 <= 0.5
    "not_delayed"    t_val99 exists but the two conditions above do not both hold
    "no_generalization"  validation accuracy never reaches 0.99 within the run
    "no_memorization"    train accuracy never reaches 0.99
Always report the ratio t_val99 / t_train99 alongside the label.
"""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

DELAY_RATIO, VAL_AT_TRAIN_MAX, THRESH = 10.0, 0.5, 0.99


def load_run(run: str | Path) -> dict:
    run = Path(run)
    rows = [json.loads(l) for l in (run / "metrics.jsonl").read_text().splitlines() if l.strip()]
    cfg = json.loads((run / "config.json").read_text())
    return {"dir": str(run), "rows": rows, "cfg": cfg, "done": (run / "DONE").exists()}


def _first(rows, key):
    return next((r["step"] for r in rows if r[key] >= THRESH), None)


def summarize(run: dict) -> dict:
    rows = run["rows"]
    t_tr, t_va = _first(rows, "train_acc"), _first(rows, "val_acc")
    val_at_tr = next((r["val_acc"] for r in rows if r["step"] == t_tr), None)
    if t_tr is None:
        label = "no_memorization"
    elif t_va is None:
        label = "no_generalization"
    elif t_va >= DELAY_RATIO * t_tr and val_at_tr <= VAL_AT_TRAIN_MAX:
        label = "delayed"
    else:
        label = "not_delayed"
    c = run["cfg"]
    return {
        "run": run["dir"], "finished": run["done"], "last_step": rows[-1]["step"],
        "config": c["name"], "paper_matched": c["_provenance"]["paper_matched"],
        "train_pct": c["data"]["train_pct"], "seed": c["train"]["seed"],
        "weight_decay": c["optim"]["weight_decay"],
        "t_train99": t_tr, "t_val99": t_va,
        "ratio": (t_va / t_tr) if (t_tr and t_va) else None,
        "val_at_train99": val_at_tr,
        "best_val_acc": max(r["val_acc"] for r in rows),
        "final_train_acc": rows[-1]["train_acc"], "final_val_acc": rows[-1]["val_acc"],
        "label": label,
    }


def plot_runs(runs: list[dict], path: str | Path, title: str = "") -> None:
    fig, (ax_a, ax_l) = plt.subplots(1, 2, figsize=(12, 4.2))
    colors = plt.rcParams["axes.prop_cycle"].by_key()["color"]
    for i, run in enumerate(runs):
        rows = [r for r in run["rows"] if r["step"] > 0]        # log x-axis
        s = [r["step"] for r in rows]
        col = colors[i % len(colors)]
        lab = f"seed {run['cfg']['train']['seed']}"
        ax_a.plot(s, [r["train_acc"] for r in rows], color=col, lw=1.2, label=f"train ({lab})")
        ax_a.plot(s, [r["val_acc"] for r in rows], color=col, lw=1.2, ls="--", label=f"val ({lab})")
        ax_l.plot(s, [r["train_loss"] for r in rows], color=col, lw=1.2)
        ax_l.plot(s, [r["val_loss"] for r in rows], color=col, lw=1.2, ls="--")
    for ax in (ax_a, ax_l):
        ax.set_xscale("log"); ax.set_xlabel("optimization step"); ax.grid(alpha=0.3)
    ax_a.set_ylabel("accuracy"); ax_a.set_ylim(-0.02, 1.02)
    ax_l.set_ylabel("loss (mean CE over loss positions)"); ax_l.set_yscale("log")
    ax_a.legend(fontsize=7, loc="upper left")
    ax_l.set_title("solid = train, dashed = validation", fontsize=9)
    fig.suptitle(title, fontsize=10)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


# Approximate visual readings of P Fig. 2 (right), x+y mod 97 panel (mean line, %).
# NOT published numbers; see docs/SETTINGS.md.
PAPER_FIG2_ADDITION_APPROX = {10: 5.0, 15: 38.0, **{p: 100.0 for p in range(20, 85, 5)}}


def sweep_table(summaries: list[dict]) -> list[dict]:
    by = {}
    for s in summaries:
        by.setdefault(s["train_pct"], []).append(s)
    out = []
    for pct in sorted(by):
        g = by[pct]
        vals = [100 * s["best_val_acc"] for s in g]
        out.append({"train_pct": pct, "n_seeds": len(g), "all_finished": all(s["finished"] for s in g),
                    "best_val_acc_per_seed": vals, "mean_best_val_acc": sum(vals) / len(vals),
                    "paper_approx_mean": PAPER_FIG2_ADDITION_APPROX.get(int(round(pct))),
                    "labels": [s["label"] for s in g],
                    "t_val99_per_seed": [s["t_val99"] for s in g]})
    return out


def plot_sweep(table: list[dict], path, title: str = "") -> None:
    fig, ax = plt.subplots(figsize=(5.5, 3.6))
    xs = [r["train_pct"] / 100 for r in table]
    for r in table:
        ax.scatter([r["train_pct"] / 100] * r["n_seeds"], r["best_val_acc_per_seed"],
                   alpha=0.35, color="C0", s=25)
    ax.plot(xs, [r["mean_best_val_acc"] for r in table], color="C0", label="this reproduction (mean)")
    ref = [(r["train_pct"] / 100, r["paper_approx_mean"]) for r in table if r["paper_approx_mean"] is not None]
    if ref:
        ax.plot(*zip(*ref), color="k", ls=":", marker="x", ms=4,
                label="paper Fig. 2 (approx. visual reading)")
    ax.set_xlabel("training data fraction"); ax.set_ylabel("best validation accuracy (%)")
    ax.set_ylim(-3, 103); ax.grid(alpha=0.3); ax.legend(fontsize=7, loc="lower right")
    ax.set_title(title, fontsize=9)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)
