"""Config loading with provenance.

Every resolved config carries a `_provenance` block listing:
  * `base`: the reproduction file it started from,
  * `filled_required`: REQUIRED (null) reproduction values that were supplied,
  * `modified`: reproduction values that were changed (=> run is NOT paper-matched).
"""
from __future__ import annotations

import copy
from pathlib import Path
from typing import Any

import yaml

CONFIG_DIR = Path(__file__).resolve().parent.parent / "configs"


def _load(path: Path) -> dict:
    with open(path) as fh:
        return yaml.safe_load(fh)


def _flatten(d: dict, prefix: str = "") -> dict[str, Any]:
    out = {}
    for k, v in d.items():
        key = f"{prefix}{k}"
        if isinstance(v, dict):
            out.update(_flatten(v, key + "."))
        else:
            out[key] = v
    return out


def _set(cfg: dict, dotted: str, value: Any) -> None:
    *parents, leaf = dotted.split(".")
    node = cfg
    for p in parents:
        if p not in node:
            raise KeyError(f"Unknown config section '{p}' in '{dotted}'")
        node = node[p]
    if leaf not in node:
        raise KeyError(f"Unknown config key '{dotted}'")
    node[leaf] = value


def load_config(
    config: str | Path = "reproduction.yaml",
    variant: str | None = None,
    cli: dict[str, Any] | None = None,
) -> dict:
    """Resolve a config. `cli` maps dotted keys (e.g. 'data.train_pct') to values."""
    path = Path(config)
    if not path.is_absolute() and not path.exists():
        path = CONFIG_DIR / path
    raw = _load(path)

    if "base" in raw:  # exploratory-style file
        base_path = path.parent / raw["base"]
        cfg = _load(base_path)
        changes = _flatten(raw.get("overrides", {}))
        if variant:
            if variant not in raw.get("variants", {}):
                raise KeyError(f"Unknown variant '{variant}'")
            changes.update(_flatten(raw["variants"][variant]))
        base_name = base_path.name
    else:
        if variant:
            raise ValueError("Variants only exist in exploratory configs")
        cfg, changes, base_name = raw, {}, path.name

    base_flat = _flatten(cfg)
    changes.update(cli or {})

    filled, modified = {}, {}
    for key, value in changes.items():
        if key not in base_flat:
            raise KeyError(f"Unknown config key '{key}'")
        original = base_flat[key]
        if original is None:
            filled[key] = value
        elif original != value:
            modified[key] = {"reproduction": original, "used": value}
        _set(cfg, key, value)

    protocol = _load(CONFIG_DIR / "protocol.yaml")
    cfg.update(protocol)
    cfg["name"] = raw["name"] + (f"/{variant}" if variant else "")
    cfg["_provenance"] = {
        "base": base_name,
        "config_file": path.name,
        "variant": variant,
        "filled_required": filled,
        "modified": modified,
        "paper_matched": not modified,
    }

    missing = [k for k, v in _flatten(cfg).items() if v is None and not k.startswith("_")]
    if missing:
        raise ValueError(
            f"REQUIRED values not supplied: {missing}. These are unspecified by the paper and "
            "code; pass them explicitly (see docs/SETTINGS.md)."
        )
    return copy.deepcopy(cfg)
