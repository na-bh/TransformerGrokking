# Grokking reproduction: modular addition (Power et al., 2022)

Reproduction of the **x + y mod 97** series of Figure 2 (right) in
*Grokking: Generalization Beyond Overfitting on Small Algorithmic Datasets*
(arXiv:2201.02177), using a decoder-only Transformer written in plain PyTorch with explicit
multi-head causal self-attention. Every setting is traced to the paper or the official code
(`openai/grok@3d64b1d`) in **[docs/SETTINGS.md](docs/SETTINGS.md)**.

## Status ledger

| Item | Implemented | Verified | Evidence |
|---|---|---|---|
| Data: token format, labels, split | yes | yes | `tests/test_data.py`; training set identical (content and order) to official `make_data()` |
| Transformer with explicit attention | yes | yes | `tests/test_model.py`: shapes, 394,240 non-embedding params, matches naive per-head loop |
| Causality / no answer leak | yes | yes | future-token invariance at every position; perturbation and gradient tests; a test that removing the mask is detected |
| Optimizer and schedule | yes | yes | `torch.optim.AdamW` equals a port of the official `CustomAdamW` to 1e-12; first update has lr 0 |
| Checkpoint / resume | yes | yes | interrupted-and-resumed run is bit-identical to an uninterrupted one (CPU) |
| Tiny-overfit sanity check (exploratory) | yes | yes (CPU) | train acc 1.0 by step 68 on 94 equations; val stays at chance (`results/explore/`) |
| Analysis / plots | yes | unit-tested on synthetic curves | `tests/test_analysis.py` |
| Colab notebook | yes | **not yet run on Colab** | `notebooks/colab_launcher.ipynb` |
| **Reproduction runs (45 × 10^5 steps)** | — | **not run** | no claim of grokking or of matching Fig. 2 is made |
| Extension (weight decay / data size) | — | — | only after the baseline |

## Layout

```
configs/reproduction.yaml   paper/code-sourced values only; unspecified ones are null (REQUIRED)
configs/protocol.yaml       our evaluation protocol (val/test split, eval cadence) - departures
configs/exploratory.yaml    chosen defaults and modifications (variants: tiny_overfit, ...)
grokrepro/data.py           equations, official vocab, split, epoch batcher
grokrepro/model.py          Transformer, explicit CausalSelfAttention
grokrepro/train.py          loss/accuracy, AdamW + warmup, logging, checkpoints
grokrepro/analysis.py       timing metrics, delayed-generalization label, plots
scripts/                    train.py, analyze.py, sweep_summary.py, final_eval.py
tests/                      pytest suite (about 1.5 min on one CPU core)
notebooks/colab_launcher.ipynb
```

## Running

```bash
pip install -e ".[test]" && python -m pytest -q
# sanity check (exploratory)
python scripts/train.py --config exploratory.yaml --variant tiny_overfit --out runs/explore/tiny_overfit
# one reproduction run (train-pct and seed are REQUIRED)
python scripts/train.py --config reproduction.yaml --train-pct 15 --seed 0 --out runs/repro/p15_s0
python scripts/analyze.py runs/repro/p15_s* --out results/repro/p15
python scripts/sweep_summary.py runs/repro --out results/repro/fig2_addition
python scripts/final_eval.py runs/repro/*     # test split, once, at the very end
```

Any change to a sourced value (`--set optim.weight_decay=0.1`) is recorded in the run's
`config.json` under `_provenance.modified`, and the run is marked `paper_matched: false`.
`analyze.py` and `sweep_summary.py` refuse to mix paper-matched and modified runs.

## Evaluation protocol

* **Validation** (half of the official held-out set) is used for all curves, timing metrics and
  any tuning (none is done in the reproduction).
* **Test** (the other half) is evaluated only by `final_eval.py`, on final checkpoints.
* "Delayed generalization" is declared only under the criterion fixed in
  `grokrepro/analysis.py`, and is reported together with the raw ratio t_val99 / t_train99.
