#!/usr/bin/env python
"""Figure-2-style summary across training fractions (validation only).

    python scripts/sweep_summary.py runs/repro --out results/repro/fig2_addition
Expects run dirs named p<pct>_s<seed>. Writes <out>.png and <out>.json.
"""
import argparse
import json
from pathlib import Path

from grokrepro.analysis import load_run, plot_sweep, summarize, sweep_table

ap = argparse.ArgumentParser()
ap.add_argument("root")
ap.add_argument("--out", required=True)
a = ap.parse_args()
runs = [load_run(d) for d in sorted(Path(a.root).glob("p*_s*")) if (d / "metrics.jsonl").exists()]
if not runs:
    raise SystemExit("no runs found")
if not all(r["cfg"]["_provenance"]["paper_matched"] for r in runs):
    raise SystemExit("Refusing: some runs under this root are not paper-matched.")
table = sweep_table([summarize(r) for r in runs])
out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
plot_sweep(table, out.with_suffix(".png"), "x+y mod 97: best validation accuracy within the run")
out.with_suffix(".json").write_text(json.dumps(table, indent=2))
for r in table:
    flag = "" if r["all_finished"] else "  (UNFINISHED runs included)"
    print(f"{r['train_pct']:>5}%  mean {r['mean_best_val_acc']:6.1f}  paper~{r['paper_approx_mean']}  "
          f"seeds {[round(v, 1) for v in r['best_val_acc_per_seed']]}  {r['labels']}{flag}")
