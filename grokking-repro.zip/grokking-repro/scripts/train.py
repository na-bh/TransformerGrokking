#!/usr/bin/env python
"""Train one run.

Reproduction (REQUIRED values must be given; nothing else may change silently):
    python scripts/train.py --config reproduction.yaml --train-pct 30 --seed 0 --out runs/repro/p30_s0
Exploratory (chosen defaults / modifications from configs/exploratory.yaml):
    python scripts/train.py --config exploratory.yaml --variant tiny_overfit --out runs/explore/tiny
Any extra change:  --set optim.weight_decay=0.1   (recorded as a modification)
Re-running the same command resumes from runs/.../checkpoints/latest.pt.
"""
import argparse
import json

import yaml

from grokrepro.config import load_config
from grokrepro.train import train

ap = argparse.ArgumentParser()
ap.add_argument("--config", default="reproduction.yaml")
ap.add_argument("--variant")
ap.add_argument("--train-pct", type=float)
ap.add_argument("--seed", type=int)
ap.add_argument("--out", required=True)
ap.add_argument("--set", action="append", default=[], metavar="KEY=VALUE")
ap.add_argument("--device")
ap.add_argument("--no-resume", action="store_true")
a = ap.parse_args()

cli = {}
if a.train_pct is not None:
    cli["data.train_pct"] = a.train_pct
if a.seed is not None:
    cli["train.seed"] = a.seed
for kv in a.set:
    k, v = kv.split("=", 1)
    cli[k] = yaml.safe_load(v)

cfg = load_config(a.config, a.variant, cli)
prov = cfg["_provenance"]
print(f"config: {cfg['name']} | paper_matched={prov['paper_matched']}")
print(f"filled REQUIRED values: {prov['filled_required']}")
if prov["modified"]:
    print("MODIFIED vs reproduction config:", json.dumps(prov["modified"]))
train(cfg, a.out, device=a.device, resume=not a.no_resume)
