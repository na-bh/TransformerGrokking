#!/usr/bin/env python
"""Evaluate the FINAL checkpoint of finished runs on the held-out TEST split (once).

    python scripts/final_eval.py runs/repro/p30_s0 [more run dirs...]
Writes <run>/test_results.json. Refuses to run on unfinished runs.
"""
import json
import sys
from pathlib import Path

import torch

from grokrepro.data import LOSS_POSITIONS, make_splits
from grokrepro.model import build_model
from grokrepro.train import evaluate

for run in map(Path, sys.argv[1:]):
    if not (run / "DONE").exists():
        print(f"skip {run}: not finished"); continue
    ck = torch.load(run / "checkpoints" / "latest.pt", map_location="cpu", weights_only=False)
    cfg = ck["config"]
    sp = make_splits(cfg)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    m = build_model(cfg, len(sp.vocab)).to(dev)
    m.load_state_dict(ck["model"])
    pos = LOSS_POSITIONS[cfg["train"]["loss_positions"]]
    res = {"step": ck["step"], "n_test": len(sp.test),
           "test": evaluate(m, sp.test.to(dev), pos),
           "val": evaluate(m, sp.val.to(dev), pos)}
    (run / "test_results.json").write_text(json.dumps(res, indent=2))
    print(run, json.dumps(res))
