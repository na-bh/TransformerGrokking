#!/usr/bin/env python
"""Summarize and plot a group of runs (e.g. all seeds of one training fraction).

    python scripts/analyze.py runs/repro/p30_s* --title "addition, 30% train" --out results/repro_p30
Writes <out>.png and <out>_summary.json. Never touches the test split.
"""
import argparse
import json
from pathlib import Path

from grokrepro.analysis import load_run, plot_runs, summarize

ap = argparse.ArgumentParser()
ap.add_argument("runs", nargs="+")
ap.add_argument("--out", required=True)
ap.add_argument("--title", default="")
a = ap.parse_args()

runs = [load_run(r) for r in a.runs]
if len({r["cfg"]["_provenance"]["paper_matched"] for r in runs}) > 1:
    raise SystemExit("Refusing to mix reproduction and exploratory runs in one summary.")
out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
plot_runs(runs, out.with_suffix(".png"), a.title)
summ = [summarize(r) for r in runs]
out.with_name(out.name + "_summary.json").write_text(json.dumps(summ, indent=2))
for s in summ:
    print({k: s[k] for k in ("run", "finished", "t_train99", "t_val99", "ratio",
                              "best_val_acc", "label")})
