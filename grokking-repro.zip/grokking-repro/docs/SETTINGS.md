# Source-backed experimental settings

Target paper: Power, Burda, Edwards, Babuschkin, Misra. *Grokking: Generalization Beyond
Overfitting on Small Algorithmic Datasets*. arXiv:2201.02177v1 (2022-01-06).

Official code: <https://github.com/openai/grok>, commit `3d64b1d8c1d595dd8ebdb7771998823f1b14c7b3`
(2024-03-16). The README states it is the code for this paper. The paper PDF itself contains
no code link; the repository was located by search and identified by its README.

## Source keys

| Key | Meaning |
|---|---|
| **P §x** | Paper section / appendix, arXiv v1 |
| **C file:line** | Official code at the commit above |
| **UNSPECIFIED** | Neither paper nor code fixes the value for this experiment |
| **CODE≠PAPER** | Code default differs from the paper; paper value used unless noted |
| **DEPARTURE** | We deliberately differ; documented reason given |

## Which experiment we target

The paper never shows a training curve for modular addition. Figure 1 (the famous grokking
curve) is **division** mod 97 at 50% data, trained with **Adam without weight decay** for 10^6
steps (P §3.1, §A.1.2). Modular addition appears in:

* **Figure 2 (right)**: best validation accuracy reached within 10^5 steps, as a function of
  training-data fraction, mean of 3 seeds, default configuration (AdamW, weight decay 1).
* **Figure 3 (right)**: t-SNE of the output-layer weights of a network trained on addition
  (training fraction not stated).

**Target:** the modular-addition series of Figure 2 (right) under the default configuration of
P §A.1.2.

**Training fractions (measured from the figure image supplied by the user):** marker centres in
the x+y panel were located by pixel analysis against the 0.2/0.4/0.6/0.8 gridlines and fall within
0.001 of **0.10, 0.15, …, 0.80** (15 values, step 0.05).

**Reference outcome (read approximately from the same figure; best val. accuracy, %):**

| Fraction | Per-seed markers | Mean (line) |
|---|---|---|
| 0.10 | three seeds ≈ 3–6 | ≈ 5 |
| 0.15 | one ≈ 100, two ≈ 7–9 | ≈ 38 |
| 0.20–0.80 | all ≈ 100 | 100 |

These are visual readings of a plot, not published numbers; treat them as ±3 points.

## Settings table

| Setting | Value | Source |
|---|---|---|
| Operation | c = (a + b) mod p, 0 ≤ a, b < p | P §A.1.1 |
| Modulus p | 97 | P §A.1.1; C data.py `MODULUS = 97` |
| Full dataset | all p² = 9409 ordered pairs, each once | P §A.1.1 ("fraction of all available equations"); C data.py:200–252 (`itertools.product`) |
| Sequence format | `<eos> a + b = c <eos>`, 7 tokens, one token per element | P §2, §A.1.1 (5-token equation); C data.py:250, 357 (EOS wrapping is code-only) |
| Vocabulary | 239 tokens shared across all tasks: `<eos>`=0, `=`=1, 20 operator tokens (`+`=6), numbers 0..96 → ids 22..118, 120 S5 permutations. Output softmax is over all 239 | C data.py:125–131 (verified by recomputation) |
| Model input / target | input = seq[:, :-1] (6 tokens); target = seq[:, 1:] (6 tokens) | C data.py:466–467 |
| Train/held-out split | Shuffle all 9409 equations with `np.random.RandomState(0)`; first `round(9409·pct/100)` are train, the rest validation | C data.py:345–347, 169 |
| Split varies with run seed? | **No** in code (shuffle seed hard-coded 0). Paper: "For each training run, we chose a fraction … at random" — ambiguous | C data.py:345 vs P §A.1.1. We follow the code |
| Training fraction | Sweep 0.10–0.80 step 0.05 (measured from Fig. 2 right). No single-run fraction is given. Code default `train_data_pct=5` is not a paper value | P Fig. 2; C training.py:102 |
| Test split | **None.** `test_dataloader` returns the validation set | C training.py:178–188 |
| Layers | 2 | P §A.1.2; C training.py:87 |
| Heads | 4 (d_head = 32) | P §A.1.2; C training.py:88 |
| Width d_model | 128 | P §A.1.2; C training.py:89 |
| FFN width | 512 (4 × d_model) | C transformer.py:181 (paper silent) |
| Non-embedding params | 394,240 (paper: "about 4·10⁵") | P §A.1.2; computed from C |
| Biases | No bias in any Linear (Q, K, V, O, FFN, unembedding). LayerNorm has weight and bias | C transformer.py:89–91, 142, 192–194, 318 |
| Embeddings | Learned token embedding (`nn.Embedding`, N(0,1) init), not scaled; untied separate unembedding | C transformer.py:301, 318, 345 |
| Positional embedding | Fixed sinusoidal, added to token embedding | C transformer.py:325–334 (paper silent) |
| Normalization | **Post-LN**: `x = LN(x + Attn(x)); x = LN(x + Drop(FFN(x)))`; no final extra LN | C transformer.py:228–234 (paper: "standard decoder-only transformer") |
| Attention | Scaled dot-product, scale 1/√d_head, causal mask (lower triangular) | P §A.1.2 ("causal attention masking"); C transformer.py:110–115, 322 |
| Activation | ReLU | C training.py:92 |
| Dropout | 0 (only exists on FFN residual branch; attention dropout commented out) | C training.py:90, transformer.py:213–217; P §3.3 lists "residual dropout 0.1" only as an ablation |
| Initialization | PyTorch defaults | C transformer.py (no custom init) |
| Precision | fp32 | C training.py:703 |
| Optimizer | AdamW (decoupled): `p ← p·(1 − lr·wd)`, then bias-corrected Adam step. Applied to **all** parameters | P §A.1.2; C training.py:851–990 (`CustomAdamW`, `to_zero`) |
| Learning rate | 1e-3 | P §A.1.2; C training.py:108 |
| Weight decay | 1 | P §A.1.2. **CODE≠PAPER**: code default 0 (C training.py:109) |
| β1, β2, ε | 0.9, 0.98, 1e-8 | P §A.1.2 (β); C training.py:225–226 (ε) |
| Schedule | Linear warmup over 10 updates, then constant. Update k (0-indexed) uses lr = min(k/10, 1)·1e-3, so update 0 has lr 0 | P §A.1.2; C training.py:190–215 + `LambdaLR` semantics |
| Annealing | None | P §A.1.2; C training.py:105 |
| Batch size | min(512, ⌈N_train/2⌉) | P §A.1.2; C data.py:435 |
| Batch sampling | Epochs: random permutation of the train set each epoch, without replacement; last smaller batch kept | C data.py:441–468 |
| Duration | 10⁵ updates | P §A.1.2; C training.py:846 |
| Seeds | 3 seeds per data fraction. Seed values **UNSPECIFIED** (code default −1 = unseeded) | P §A.1.2; C training.py:843 |
| Loss | Cross-entropy averaged over the target positions **after `=`**: the answer `c` *and* the trailing `<eos>` | P §A.1.2 ("only on the answer part"); C training.py:301–314 resolves it to 2 tokens |
| Accuracy | Argmax over all 239 tokens; an example is correct only if **both** `c` and `<eos>` are correct | C training.py:251–267 |
| Evaluation | Full validation set in one batch; also full-train loss/acc at the same moments. Evaluated every epoch, then at epochs growing ×1.02 | C training.py:164–176, 562–599 |
| Fig. 2 metric | Best validation accuracy within 10⁵ steps, mean over 3 seeds | P Fig. 2 caption |
| Grokking-time metric | First step where accuracy reaches 99% (train or validation) | P §3.1.1, Fig. 1 caption |

## Our departures (all documented, none silent)

1. **Held-out split into validation and test (DEPARTURE).** The paper and code have only
   train/validation. We keep the training set *identical* to the official one and partition the
   official validation set 50/50 (fixed seed) into validation and test. Validation curves are
   therefore computed on half of the paper's held-out set. Test is used only once, after
   training. Nothing in the reproduction configuration is tuned.
2. **Evaluation cadence (DEPARTURE, no effect on training).** We evaluate on a step schedule
   (log-spaced early, then every `eval_every` steps) rather than the epoch ×1.02 schedule.
   Evaluation runs under `torch.no_grad()` with dropout 0, so it does not consume random numbers
   or change training.
3. **Fused Q/K/V matrices (implementation detail).** Official code has per-head 128→32 matrices;
   we use one 128→128 matrix per Q/K/V, split into heads. Same function class, same init
   distribution (PyTorch's init bound depends only on fan-in = 128).
4. **Data-order RNG.** We draw epoch permutations from a dedicated `torch.Generator` seeded by
   the run seed (official: global RNG). Same distribution; simpler exact resumption.
5. **Extra diagnostics.** We additionally log answer-only loss/accuracy (just `c`), which does
   not feed the gradient.

## Things to keep in mind when comparing numbers

* The paper's loss averages over two tokens, one of which (`<eos>`) becomes trivial. After the
  model learns `<eos>`, the reported loss is about **half** of the answer-token loss. Do not
  compare it directly with papers that use answer-only loss (e.g. Nanda et al. 2023).
* With weight decay 1, the paper reports addition generalizing at low data fractions within
  10⁵ steps; the *long* delays of Figure 1 come from a different setting (division, no weight
  decay, 10⁶ steps).
