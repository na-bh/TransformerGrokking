import json
import math

import torch

from grokrepro.config import load_config
from grokrepro.data import LOSS_POSITIONS
from grokrepro.train import lr_lambda_factory, seq_loss_and_correct, train


def tiny_cfg(**cli):
    base = {"data.train_pct": 2.0, "train.seed": 0, "train.max_steps": 60}
    base.update(cli)
    c = load_config("exploratory.yaml", cli=base)
    c["protocol"].update(eval_every=10, eval_log_points=5, checkpoint_every=20)
    return c


def test_lr_schedule_matches_official():
    f = lr_lambda_factory(10)
    assert [f(k) for k in (0, 1, 5, 10, 11, 10_000)] == [0.0, 0.1, 0.5, 1.0, 1.0, 1.0]
    # LambdaLR applies f(k) to update k: first update has lr 0.
    p = torch.nn.Parameter(torch.zeros(1))
    opt = torch.optim.AdamW([p], lr=1e-3)
    sch = torch.optim.lr_scheduler.LambdaLR(opt, f)
    lrs = []
    for _ in range(12):
        lrs.append(opt.param_groups[0]["lr"])
        opt.step(); sch.step()
    assert lrs[0] == 0.0 and math.isclose(lrs[3], 3e-4) and math.isclose(lrs[11], 1e-3)


def _official_adamw_to_zero(p, grads, lrs, wd, betas=(0.9, 0.98), eps=1e-8):
    """Port of C training.py CustomAdamW.step, weight_decay_form='to_zero', noise 0."""
    p = p.clone(); m = torch.zeros_like(p); v = torch.zeros_like(p)
    for t, (g, lr) in enumerate(zip(grads, lrs), start=1):
        p.mul_(1 - lr * wd)
        m.mul_(betas[0]).add_(g, alpha=1 - betas[0])
        v.mul_(betas[1]).addcmul_(g, g, value=1 - betas[1])
        denom = (v.sqrt() / math.sqrt(1 - betas[1] ** t)).add_(eps)
        p.add_(-(lr / (1 - betas[0] ** t)) * (m / denom))
    return p


def test_torch_adamw_equals_official_custom_adamw():
    torch.manual_seed(0)
    p0 = torch.randn(50, dtype=torch.float64)
    grads = [torch.randn(50, dtype=torch.float64) for _ in range(25)]
    f = lr_lambda_factory(10)
    lrs = [1e-3 * f(k) for k in range(25)]
    ref = _official_adamw_to_zero(p0, grads, lrs, wd=1.0)
    p = torch.nn.Parameter(p0.clone())
    opt = torch.optim.AdamW([p], lr=1e-3, betas=(0.9, 0.98), eps=1e-8, weight_decay=1.0)
    sch = torch.optim.lr_scheduler.LambdaLR(opt, f)
    for g in grads:
        p.grad = g.clone(); opt.step(); sch.step()
    assert torch.allclose(p.detach(), ref, atol=1e-12)


def test_loss_positions_and_accuracy_rule():
    V = 5
    y = torch.tensor([[0, 1, 2, 3, 4, 0]])
    logits = torch.full((1, 6, V), -10.0)
    logits[0, 4, 4] = 10.0           # answer correct
    logits[0, 5, 1] = 10.0           # trailing <eos> wrong (target 0)
    _, c_rhs = seq_loss_and_correct(logits, y, LOSS_POSITIONS["rhs_after_eq"])
    _, c_ans = seq_loss_and_correct(logits, y, LOSS_POSITIONS["answer_only"])
    assert not c_rhs.item() and c_ans.item()    # official accuracy requires both tokens


def test_resume_is_bit_exact(tmp_path):
    cfg = tiny_cfg()
    full = train(cfg, tmp_path / "full", device="cpu", quiet=True)
    part = tmp_path / "part"
    train(cfg, part, device="cpu", quiet=True, stop_at=33)      # stops off a checkpoint boundary
    train(cfg, part, device="cpu", quiet=True)                  # resumes from step 33
    a = torch.load(full / "checkpoints" / "latest.pt", weights_only=False)
    b = torch.load(part / "checkpoints" / "latest.pt", weights_only=False)
    assert a["step"] == b["step"] == 60
    for k in a["model"]:
        assert torch.equal(a["model"][k], b["model"][k]), k
    ra = [json.loads(l) for l in (full / "metrics.jsonl").read_text().splitlines()]
    rb = [json.loads(l) for l in (part / "metrics.jsonl").read_text().splitlines()]
    assert [r["step"] for r in ra] == [r["step"] for r in rb]
    assert [r["val_loss"] for r in ra] == [r["val_loss"] for r in rb]


def test_provenance_flags_modifications():
    c = load_config("reproduction.yaml", cli={"data.train_pct": 30.0, "train.seed": 1})
    assert c["_provenance"]["paper_matched"]
    c = load_config("reproduction.yaml",
                    cli={"data.train_pct": 30.0, "train.seed": 1, "optim.weight_decay": 0.1})
    assert not c["_provenance"]["paper_matched"]
    assert "optim.weight_decay" in c["_provenance"]["modified"]
