import json

from grokrepro.analysis import load_run, summarize, sweep_table
from grokrepro.config import load_config


def fake_run(tmp, name, curve, pct=30.0, seed=0):
    d = tmp / name; d.mkdir()
    cfg = load_config("reproduction.yaml", cli={"data.train_pct": pct, "train.seed": seed})
    (d / "config.json").write_text(json.dumps(cfg))
    (d / "metrics.jsonl").write_text("".join(
        json.dumps({"step": s, "train_acc": tr, "val_acc": va}) + "\n" for s, tr, va in curve))
    (d / "DONE").write_text("")
    return load_run(d)


def test_delay_labels(tmp_path):
    delayed = fake_run(tmp_path, "a", [(0, 0, 0), (100, 1.0, 0.05), (5000, 1.0, 0.995)])
    fast = fake_run(tmp_path, "b", [(0, 0, 0), (100, 0.995, 0.8), (300, 1.0, 0.999)])
    never = fake_run(tmp_path, "c", [(0, 0, 0), (100, 1.0, 0.05), (9000, 1.0, 0.3)])
    s = [summarize(r) for r in (delayed, fast, never)]
    assert [x["label"] for x in s] == ["delayed", "not_delayed", "no_generalization"]
    assert s[0]["ratio"] == 50 and s[0]["t_train99"] == 100


def test_sweep_table_means(tmp_path):
    runs = [fake_run(tmp_path, f"p15_s{i}", [(0, 0, 0), (10, 1.0, v)], pct=15.0, seed=i)
            for i, v in enumerate([1.0, 0.08, 0.06])]
    t = sweep_table([summarize(r) for r in runs])
    assert len(t) == 1 and abs(t[0]["mean_best_val_acc"] - 38.0) < 1e-6
    assert t[0]["paper_approx_mean"] == 38.0
