import math

import pytest
import torch

from grokrepro.config import load_config
from grokrepro.data import ANSWER_POS_IN_Y, inputs_targets, make_splits
from grokrepro.model import build_model, count_params, sinusoidal_positions

CFG = load_config("reproduction.yaml", cli={"data.train_pct": 50.0, "train.seed": 0})
SP = make_splits(CFG)
V = len(SP.vocab)


def model(dropout=0.0):
    torch.manual_seed(0)
    c = {**CFG, "model": {**CFG["model"], "dropout": dropout}}
    return build_model(c, V).eval()


def test_param_count_matches_paper():
    n = count_params(model())
    # 2 x (4*128*128 attention + 2*128*512 FFN + 2*2*128 LayerNorm) = 394,240
    assert n["non_embedding"] == 394_240
    assert n["embedding_and_unembedding"] == 2 * 239 * 128


def test_positional_encoding_matches_official_formula():
    pe = sinusoidal_positions(50, 128)
    for pos in (0, 3, 49):
        for i in (0, 1, 2, 77, 127):
            ref = (math.sin(pos / 10000 ** (i / 128)) if i % 2 == 0
                   else math.cos(pos / 10000 ** ((i - 1) / 128)))
            assert abs(pe[pos, i].item() - ref) < 1e-6


def test_shapes_and_attention_weights():
    m = model()
    x, _ = inputs_targets(SP.train[:8])
    logits, ws = m(x, return_weights=True)
    assert x.shape == (8, 6) and logits.shape == (8, 6, V)
    assert len(ws) == 2
    for w in ws:
        assert w.shape == (8, 4, 6, 6)
        assert torch.allclose(w.sum(-1), torch.ones(8, 4, 6), atol=1e-6)
        assert (w.triu(diagonal=1) == 0).all()          # no weight on future keys


def test_explicit_attention_matches_naive_per_head_loop():
    m = model()
    attn = m.blocks[0].attn
    h = torch.randn(3, 6, 128)
    out, _ = attn(h)
    Wq, Wk, Wv = attn.W_q.weight, attn.W_k.weight, attn.W_v.weight
    heads = []
    for hd in range(4):
        sl = slice(32 * hd, 32 * (hd + 1))
        q, k, v = h @ Wq[sl].T, h @ Wk[sl].T, h @ Wv[sl].T
        res = torch.zeros(3, 6, 32)
        for i in range(6):                                # query position
            s = torch.stack([(q[:, i] * k[:, j]).sum(-1) / math.sqrt(32) for j in range(i + 1)], -1)
            p = torch.softmax(s, -1)
            res[:, i] = sum(p[:, j:j + 1] * v[:, j] for j in range(i + 1))
        heads.append(res)
    ref = attn.W_o(torch.cat(heads, -1))
    assert torch.allclose(out, ref, atol=1e-5)


@pytest.mark.parametrize("t", range(5))
def test_future_tokens_cannot_change_earlier_logits(t):
    """Changing any token at positions > t leaves logits at positions <= t unchanged (eval mode)."""
    m = model(dropout=0.1)        # eval() disables dropout; check it doesn't matter
    x, _ = inputs_targets(SP.train[:16])
    x2 = x.clone()
    g = torch.Generator().manual_seed(t)
    x2[:, t + 1:] = torch.randint(0, V, x2[:, t + 1:].shape, generator=g)
    with torch.no_grad():
        a, b = m(x), m(x2)
    assert torch.equal(a[:, : t + 1], b[:, : t + 1])
    assert not torch.allclose(a[:, t + 1:], b[:, t + 1:])   # sanity: later positions do change


def test_answer_not_leaked_into_its_prediction_position():
    """The answer c is predicted from input position 4 ('='). c sits at input position 5."""
    x, y = inputs_targets(SP.train[:64])
    pred_pos = ANSWER_POS_IN_Y                          # logits[:, 4] predict y[:, 4] = c
    assert (x[:, pred_pos] == SP.stoi["="]).all()
    assert torch.equal(y[:, pred_pos], SP.train[:64, 5])  # target is c
    assert torch.equal(x[:, :pred_pos + 1], SP.train[:64, :5])  # inputs up to '=' exclude c

    m = model()
    # 1) Replace c with every other number: answer-position logits do not move.
    with torch.no_grad():
        base = m(x)[:, pred_pos]
        for shift in (1, 13, 50):
            x2 = x.clone()
            x2[:, 5] = 22 + (x2[:, 5] - 22 + shift) % 97
            assert torch.equal(m(x2)[:, pred_pos], base)
    # 2) Gradient check: d(answer logits)/d(input embedding at position 5) == 0.
    emb = (m.embed(x) + m.pos[:6]).detach().requires_grad_(True)
    h = emb
    for blk in m.blocks:
        h, _ = blk(h)
    m.unembed(h)[:, pred_pos].sum().backward()
    assert emb.grad[:, 5].abs().max().item() == 0.0
    assert emb.grad[:, :5].abs().max().item() > 0.0


def test_mask_removal_would_be_detected():
    """Negative control: with the mask disabled, the future-token test must fail."""
    m = model()
    for blk in m.blocks:
        blk.attn.causal_mask.fill_(True)
    x, _ = inputs_targets(SP.train[:16])
    x2 = x.clone()
    x2[:, 5] = 22 + (x2[:, 5] - 22 + 1) % 97
    with torch.no_grad():
        assert not torch.equal(m(x)[:, 4], m(x2)[:, 4])
