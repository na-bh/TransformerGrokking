import itertools
import os

import numpy as np
import pytest
import torch

from grokrepro.config import load_config
from grokrepro.data import (EOS, EQ, EpochBatcher, build_vocab, inputs_targets, make_splits,
                            official_batch_size)


def cfg(pct=50.0):
    return load_config("reproduction.yaml", cli={"data.train_pct": pct, "train.seed": 0})


def test_official_vocab_ids():
    v = build_vocab("official", 97)
    s = {t: i for i, t in enumerate(v)}
    assert len(v) == len(set(v)) == 239
    assert (s[EOS], s[EQ], s["+"], s["0"], s["96"]) == (0, 1, 6, 22, 118)


@pytest.mark.parametrize("pct", [10.0, 30.0, 50.0])
def test_labels_are_modular_sums(pct):
    sp = make_splits(cfg(pct))
    for seq in (sp.train, sp.val, sp.test):
        a = np.array([int(sp.vocab[t]) for t in seq[:, 1].tolist()])
        b = np.array([int(sp.vocab[t]) for t in seq[:, 3].tolist()])
        c = np.array([int(sp.vocab[t]) for t in seq[:, 5].tolist()])
        assert np.array_equal(c, (a + b) % 97)


def test_sequence_format_and_shapes():
    sp = make_splits(cfg())
    s = sp.stoi
    assert sp.train.shape[1] == 7 and sp.train.dtype == torch.int64
    for col, tok in [(0, EOS), (2, "+"), (4, EQ), (6, EOS)]:
        assert (sp.train[:, col] == s[tok]).all()
    x, y = inputs_targets(sp.train)
    assert x.shape == y.shape == (len(sp.train), 6)
    assert torch.equal(x[:, 1:], y[:, :-1])          # y is x shifted left by one


@pytest.mark.parametrize("pct", [1.0, 30.0, 50.0, 95.0])
def test_splits_disjoint_and_complete(pct):
    sp = make_splits(cfg(pct))
    sets = [set(map(tuple, p.tolist())) for p in (sp.train_pairs, sp.val_pairs, sp.test_pairs)]
    assert sum(len(s) for s in sets) == 97 * 97            # no duplicates inside a split
    assert not (sets[0] & sets[1]) and not (sets[0] & sets[2]) and not (sets[1] & sets[2])
    assert set.union(*sets) == set(itertools.product(range(97), repeat=2))
    assert len(sp.train) == round(9409 * pct / 100)


def test_split_independent_of_run_seed():
    a = make_splits(load_config("reproduction.yaml", cli={"data.train_pct": 30.0, "train.seed": 0}))
    b = make_splits(load_config("reproduction.yaml", cli={"data.train_pct": 30.0, "train.seed": 7}))
    assert torch.equal(a.train, b.train) and torch.equal(a.val, b.val)


def test_batch_size_rule():
    assert official_batch_size(4704) == 512
    assert official_batch_size(94) == 47
    assert official_batch_size(95) == 48


def test_epoch_batcher_covers_each_example_once_per_epoch():
    b = EpochBatcher(n=1000, batch_size=300, seed=0)
    seen = torch.cat([b.next_indices() for _ in range(4)])   # 300,300,300,100
    assert sorted(seen.tolist()) == list(range(1000))
    assert b.next_indices().shape[0] == 300 and b.epoch == 1


OFFICIAL = os.environ.get("GROK_OFFICIAL_PATH")


@pytest.mark.skipif(not OFFICIAL, reason="set GROK_OFFICIAL_PATH to an openai/grok checkout")
def test_matches_official_split_exactly():
    """Cross-check against the official make_data() (needs: sympy, mod, blobfile)."""
    import importlib.util
    spec = importlib.util.spec_from_file_location("official_data", f"{OFFICIAL}/grok/data.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)          # load data.py alone; avoids pytorch_lightning import
    ArithmeticDataset = mod.ArithmeticDataset
    off = ArithmeticDataset.make_data("+")                   # shuffled with RandomState(0)
    n_train, _ = ArithmeticDataset.calc_split_len(30.0, len(off))
    assert len(off) == 9409 and off[0].split()[0] == "<|eos|>"
    off_train = [tuple(e.split()[1:6]) for e in off[:n_train]]
    off_heldout = {tuple(e.split()[1:6]) for e in off[n_train:]}
    sp = make_splits(cfg(30.0))
    ours = lambda seq: {tuple(sp.vocab[t] for t in r[1:6]) for r in seq.tolist()}
    # identical training set AND identical order
    assert [tuple(sp.vocab[t] for t in r[1:6]) for r in sp.train.tolist()] == off_train
    assert ours(sp.val) | ours(sp.test) == off_heldout
